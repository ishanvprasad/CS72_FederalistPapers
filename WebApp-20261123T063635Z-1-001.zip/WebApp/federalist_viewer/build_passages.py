"""Extract the 10 human-annotated passages from the notebook's saved cell output.

Usage: python build_passages.py path/to/federalist_old_to_modern_lora_v3.ipynb

What is recovered from the notebook text:
  * SOURCE / OUTPUT A / OUTPUT B for each rated item (re-joined from the 110-column wrapping)
  * the Likert ratings (meaning / simplicity / fluency, 1-5), meaning-error counts and the free-text note
What is recomputed:
  * which system was shown as A or B, by replaying the notebook's own seeded RNG (SEED + 7)
What is NOT in the notebook:
  * per-passage classifier / BERTScore / SARI values  -> read from per_chunk_metrics_v3.csv by app.py
"""
import json, re, sys
import numpy as np

SEED, N_MINI, N_TEST = 42, 15, 69
SYS_X, SYS_Y = "v3 adapter", "Qwen-7B zero-shot (teacher)"
HUMAN_CELL = "HUMAN CHECK (Likert)"

def rejoin(block: str) -> str:
    out = ""
    for line in block.strip().splitlines():
        line = line.strip()
        if not line: continue
        # textwrap.fill breaks after hyphens ("courts-" / "martial"): glue those back together
        out += line if (not out or out.endswith("-")) else " " + line
    return out

def main(path):
    nb = json.load(open(path, encoding="utf-8"))
    cell = next(c for c in nb["cells"] if c["cell_type"] == "code" and HUMAN_CELL in "".join(c["source"]))
    text = "".join("".join(o.get("text", "")) for o in cell["outputs"])

    # replay the notebook's sampling so A/B can be resolved to a system
    rng = np.random.default_rng(SEED + 7)
    pick = sorted(rng.choice(N_TEST, size=N_MINI, replace=False).tolist())
    a_is_x = rng.random(N_MINI) < 0.5

    # split into ITEM blocks; a redone item appears twice, keep the last one
    blocks = {}
    for m in re.finditer(r"ITEM (\d+)/15\n(.*?)(?=\n={20,}\nITEM|\Z)", text, re.S):
        blocks[int(m.group(1))] = m.group(2)

    rate = re.compile(r"A: meaning (\d), simplicity (\d), fluency (\d), errors (\d)\s+\|\s+B: meaning (\d), simplicity (\d), fluency (\d), errors (\d)")
    items = []
    for n in sorted(blocks):
        b = blocks[n]
        m = rate.search(b)
        if not m: continue                      # item shown but never rated (item 11)
        g = list(map(int, m.groups()))
        sec = lambda a, z: rejoin(re.search(a + r"\n(.*?)\n\n" + z, b, re.S).group(1))
        src, oa = sec("SOURCE:", "OUTPUT A:"), sec("OUTPUT A:", "OUTPUT B:")
        ob = rejoin(re.search(r"OUTPUT B:\n(.*?)\n\nA: meaning/", b, re.S).group(1))
        nm = re.search(r"Brief note on the worst problem \(Enter to skip\):[ \t]*(.*)", b)
        note = nm.group(1).strip() if nm else ""
        sa, sb = (SYS_X, SYS_Y) if a_is_x[n - 1] else (SYS_Y, SYS_X)
        def rec(slot, system, r, e, o):
            return dict(slot=slot, system=system, text=o,
                        human=dict(meaning=r[0], simplicity=r[1], fluency=r[2], errors=e))
        items.append(dict(
            item=n, test_index=pick[n - 1], source=src, note=note,
            outputs=[rec("A", sa, g[0:3], g[3], oa), rec("B", sb, g[4:7], g[7], ob)]))
    return items

if __name__ == "__main__":
    items = main(sys.argv[1])
    json.dump(items, open("data/passages.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(len(items), "rated passages written to data/passages.json")
    for it in items:
        print(it["item"], "idx", it["test_index"], [(o["slot"], o["system"][:6], o["human"]) for o in it["outputs"]], "| note:", it["note"][:50])

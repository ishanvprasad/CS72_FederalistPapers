# Federalist annotated-passages viewer

    python app.py            # then open http://localhost:8000

Python 3.8+ standard library only. Use `--port 8123` to change the port.

## Adding the automatic metrics

The notebook only prints averages. The per-passage values are in `per_chunk_metrics_v3.csv`
(Drive: `federalist_lora/v3/`). Either drop that file into `data/`, or drag it onto the page.

The app reads three columns: `clf_p_modern` (mean P(modern)), `bertscore_src` (BERTScore F1 vs source), `sari`.
Rows are matched by position: the notebook writes one row per test chunk per system in test-set order, so
row N of each system is test chunk N. The app checks that the chunk ids in the file belong to the expected
Federalist papers (31, 40, 50, 59) and shows a warning if not.

## Data

`data/passages.json` was extracted from the notebook's saved output by `build_passages.py`
(`python build_passages.py your_notebook.ipynb` regenerates it). It holds the source text, both outputs,
the human 1-5 ratings (meaning / simplicity / fluency), meaning-error counts and the rater's note for
the 10 rated items. Item 11 was displayed but never rated, so it is excluded.

Which system was Output A or B was not printed (it was hidden during rating). It is recomputed by
replaying the notebook's seeded RNG (`default_rng(SEED + 7)`).

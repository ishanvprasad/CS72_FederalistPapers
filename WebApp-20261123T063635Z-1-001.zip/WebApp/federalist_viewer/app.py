#!/usr/bin/env python3
"""Localhost viewer for the 10 human-annotated Federalist passages.

    python app.py            # then open http://localhost:8000
    python app.py --port 8123

No third-party packages needed (Python 3.8+ standard library only).

Data sources
  data/passages.json            passages, outputs, human ratings + notes (built from the notebook by build_passages.py)
  data/per_chunk_metrics_v3.csv automatic metrics written by the notebook (drop it in, or upload from the page)
"""
import argparse, csv, json, math, mimetypes, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).parent
DATA = ROOT / "data"
PASSAGES = DATA / "passages.json"
METRICS = DATA / "per_chunk_metrics_v3.csv"
SOURCE_SYS = "source (Federalist)"
# the three metrics the page shows -> CSV column
COLS = {"p_modern": "clf_p_modern", "bertscore": "bertscore_src", "sari": "sari"}
# Federalist number of each rated item (items 1-2, 3-6, 7-9, 10 come from papers 31, 40, 50, 59)
PAPER = {1: 31, 2: 31, 3: 40, 4: 40, 5: 40, 6: 40, 7: 50, 8: 50, 9: 50, 10: 59}


def num(x):
    try:
        v = float(x)
        return None if math.isnan(v) else v
    except (TypeError, ValueError):
        return None


def load_metrics():
    """{system: [row, row, ...]} in file order. The notebook writes one row per test chunk for each
    system, in test-set order, so the n-th row of a system is test chunk n."""
    if not METRICS.exists():
        return None
    by = {}
    with open(METRICS, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            by.setdefault(r["system"], []).append(r)
    return by


def build_payload():
    items = json.loads(PASSAGES.read_text(encoding="utf-8"))
    by = load_metrics()
    warnings = []
    if by is not None:
        need = {SOURCE_SYS, *(o["system"] for it in items for o in it["outputs"])}
        missing = need - set(by)
        if missing:
            warnings.append(f"CSV has no rows for: {', '.join(sorted(missing))}")
            by = None
    for it in items:
        idx, paper = it["test_index"], PAPER.get(it["item"])
        it["paper"] = paper
        it["words"] = len(it["source"].split())
        it["chunk_id"] = None
        it["source_p_modern"] = None
        for o in it["outputs"]:
            o["metrics"] = {k: None for k in COLS}
            o["words"] = len(o["text"].split())
            o["len_ratio"] = round(o["words"] / it["words"], 2)
        if by is None:
            continue
        try:
            src = by[SOURCE_SYS][idx]
            it["chunk_id"] = src["id"]
            it["source_p_modern"] = num(src["clf_p_modern"])
            if paper and not src["id"].startswith(f"fed{paper}_"):
                warnings.append(f"Item {it['item']}: expected a Federalist No. {paper} chunk but row {idx} is {src['id']}; "
                                "the CSV may not come from the same run as the notebook output.")
            for o in it["outputs"]:
                row = by[o["system"]][idx]
                if row["id"] != src["id"]:
                    warnings.append(f"Item {it['item']}: chunk id mismatch between systems ({row['id']} vs {src['id']}).")
                o["metrics"] = {k: num(row.get(c)) for k, c in COLS.items()}
        except (IndexError, KeyError):
            warnings.append(f"Item {it['item']}: could not find test chunk #{idx} in the metrics CSV.")
    return {"items": items, "metrics_loaded": by is not None, "warnings": warnings}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/data":
            try:
                return self._send(200, build_payload())
            except Exception as e:                       # surface data problems in the UI rather than a blank page
                return self._send(500, {"error": f"{type(e).__name__}: {e}"})
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        f = (ROOT / "static" / rel).resolve()
        if (ROOT / "static") in f.parents and f.is_file():
            return self._send(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream")
        self._send(404, {"error": "not found"})

    def do_POST(self):
        url = urlparse(self.path)
        if url.path == "/api/upload-metrics":
            n = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(n)
            head = body[:4000].decode("utf-8", "ignore").splitlines()[:1]
            cols = set(head[0].strip().split(",")) if head else set()
            if not {"system", "id", *COLS.values()} <= cols:
                return self._send(400, {"error": "That does not look like per_chunk_metrics_v3.csv "
                                                 "(needs system, id, clf_p_modern, bertscore_src, sari columns)."})
            DATA.mkdir(exist_ok=True)
            METRICS.write_bytes(body)
            return self._send(200, {"ok": True})
        if url.path == "/api/clear-metrics":
            METRICS.unlink(missing_ok=True)
            return self._send(200, {"ok": True})
        self._send(404, {"error": "not found"})

    def log_message(self, fmt, *a):
        pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args()
    if not PASSAGES.exists():
        raise SystemExit("data/passages.json is missing. Run: python build_passages.py <notebook.ipynb>")
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    print(f"Serving on http://{a.host}:{a.port}   (Ctrl+C to stop)")
    print("Metrics CSV:", "found" if METRICS.exists() else "not found yet - upload it from the page or copy it to data/")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
